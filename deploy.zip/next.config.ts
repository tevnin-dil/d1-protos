import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Minimal config for wireframe kit
};

export default nextConfig;
